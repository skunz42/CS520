#include <stdio.h>

int bakery_time;
int no_request;
int bagel_baked;
int baguette_baked;
int baking_count;
float performance;
